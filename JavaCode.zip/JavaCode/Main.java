import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Main{
    public static void main (String []args){

        AFrame f = new AFrame("学生信息管理系统");
    }
}


class AFrame extends JFrame {
    JButton b1;
    JButton b2;
    JTextField t1;
    JTextField t2;

    public AFrame(String title) {
        super(title);
        //调用父类JFrame的构造函数，将指定的title作为窗口的标题。
        this.setLayout(null);
        //设置布局管理器为null，即使用自定义的布局方式。
        Panel p = new Panel();

        b1 = new JButton("登陆");
        //创建一个按钮对象b1，按钮上显示文本为"登陆"。
        b2 = new JButton("取消");
        //创建一个按钮对象b2，按钮上显示文本为"取消"。
        t1 = new JTextField(25);
        //创建一个文本框对象t1，宽度为25个字符。
        t1.setFont(new Font("宋体", Font.BOLD, 25));
        //设置文本框的字体为宋体，加粗，大小为25。
        t2 = new JPasswordField(25);
        //创建一个密码框对象t2，宽度为25个字符。
        t2.setFont(new Font("宋体", Font.BOLD, 25));
        //设置密码框的字体为宋体，加粗，大小为25。
        JLabel nameLabel = new JLabel("用户名");
        //创建一个标签对象nameLabel，显示文本为"用户名"。
        nameLabel.setFont(new Font("宋体", Font.BOLD, 25));
        //设置标签的字体为宋体，加粗，大小为25。
        nameLabel.setHorizontalAlignment(JTextField.CENTER);
        //设置标签的文本居中对齐。
        JLabel pwdLabel = new JLabel("密码");
        //创建一个标签对象pwdLabel，显示文本为"密码"。
        pwdLabel.setFont(new Font("宋体", Font.BOLD, 25));
        //设置标签的字体为宋体，加粗，大小为25。
        pwdLabel.setHorizontalAlignment(JTextField.CENTER);
        //设置标签的文本居中对齐
        //所谓居中对齐实质就是用户名和密码居中对齐
        this.setBounds(300, 300, 2000, 1000);
        //设置窗口的位置和大小，横坐标和纵坐标均为300，窗口的长为1000，宽为500。
        this.add(nameLabel);
        //将nameLabel标签添加到窗口中。
        this.add(t1);
        //将t1文本框添加到窗口中。
        this.add(pwdLabel);
        //将pwdLabel标签添加到窗口中。
        this.add(t2);
        //将t2密码框添加到窗口中。
        this.add(b1);
        //将b1按钮添加到窗口中。
        this.add(b2);
        //将b2按钮添加到窗口中。

        nameLabel.setBounds(100, 100, 200, 50);
        //设置nameLabel标签在窗口中的位置和大小，参数依次为左上角的横坐标、纵坐标、宽度和高度。
        //用户名
        pwdLabel.setBounds(100, 200, 200, 50);
        //设置pwdLabel标签在窗口中的位置和大小，参数依次为左上角的横坐标、纵坐标、宽度和高度。
        //密码
        t1.setBounds(600, 100, 200, 50);
        //设置t1文本框在窗口中的位置和大小，参数依次为左上角的横坐标、纵坐标、宽度和高度。
        //用户名输入文本框
        t2.setBounds(600, 200, 200, 50);
        //设置t2密码框在窗口中的位置和大小，参数依次为左上角的横坐标、纵坐标、宽度和高度。
        //密码输入文本框
        b1.setBounds(100, 300, 300, 80);
        //设置b1按钮在窗口中的位置和大小，参数依次为左上角的横坐标、纵坐标、宽度和高度。
        //b1按钮是登录按钮
        b2.setBounds(600, 300, 300, 80);
        //设置b2按钮在窗口中的位置和大小，参数依次为左上角的横坐标、纵坐标、宽度和高度。
        //b2按钮是取消按钮
        b1.addActionListener(new ResponseButton());
        //为b1按钮添加一个点击事件的监听器，使用ResponseButton类实现。
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "单击确定退出");
                System.exit(0);
            }
        });
        //为b2按钮添加一个点击事件的监听器，使用匿名内部类实现，点击按钮时弹出一个对话框提示确认退出，
        // 并调用System.exit(0)退出程序。

        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //设置窗口的默认关闭操作为退出程序。
        this.setVisible(true);
        //设置窗口可见。
        getRootPane().setDefaultButton(b1);
        //设置窗口的默认按钮为b1按钮，即按下回车键时触发b1按钮的点击事件。
        b1.addKeyListener(new KeyAdapter() {

            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    AFrame2 f1 = new AFrame2("学生信息管理系统-123456");

                } else {
                    System.out.print(t1.getText());
                    JOptionPane.showMessageDialog(null, "账号或者密码错误", "Error.mxy", JOptionPane.ERROR_MESSAGE);

                }
            }
        });
        //为b1按钮添加一个键盘事件的监听器，使用匿名内部类实现。如果按下回车键，则创建一个AFrame2对象表示学生信息管理系统的主界面；
        // 否则，打印t1文本框中的文本并显示错误消息提示框。

    }

    public class ResponseButton implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String str = "qc";
            //用户名文本
            String m = "qc666";
            //密码文本
            if (t1.getText().equals(str) && t2.getText().equals(m)) {
                //使用t1.getText()获取t1文本框中的内容，使用t2.getText()获取t2文本框中的内容。
                // 也就是读取用户输入的用户名和密码

                AFrame2 f1 = new AFrame2("学生信息管理系统-123456");

            } else {
                System.out.print(t1.getText());
                JOptionPane.showMessageDialog(null, "账号或者密码错误", "Error.mxy", JOptionPane.ERROR_MESSAGE);

            }
        }
    }

    class AFrame2 extends JFrame {
        JButton b3;
        JButton b4;
        JButton b5;
        JButton b6;

        public AFrame2(String title) {
            super(title);
            //构造函数 AFrame2 接受一个字符串参数 title，用作窗口的标题。
            //在构造函数内部，通过调用父类 JFrame 的构造函数并传递 title，初始化窗口的标题。
            b3 = new JButton("录入");
            b4 = new JButton("查询");
            b5 = new JButton("修改");
            b6 = new JButton("删除");

            this.add(b3);
            this.add(b4);
            this.add(b5);
            this.add(b6);

            b3.setBounds(100, 80, 160, 100);
            b4.setBounds(100, 290, 160, 100);
            b5.setBounds(300, 80, 160, 100);
            b6.setBounds(300, 290, 160, 100);
            //调整按钮大小和位置


            b3.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    AFrame3 f2 = new AFrame3("学生信息管理系统-录入");
                }
            });
            //为 b3 按钮添加一个动作监听器（ActionListener），并实现其 actionPerformed 方法。
            // 当按钮被点击时，会创建一个新的 AFrame3 对象，窗口标题为 "学生信息管理系统-录入"。
            b4.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    AFrame4 f3 = new AFrame4("学生信息管理系统-查询");
                }
            });
            //为 b4 按钮添加一个动作监听器，实现其 actionPerformed 方法。
            // 当按钮被点击时，会创建一个新的 AFrame4 对象，窗口标题为 "学生信息管理系统-查询"。
            b5.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    AFrame5 f4 = new AFrame5("学生信息管理系统-修改");

                }
            });
            //为 b5 按钮添加一个动作监听器，实现其 actionPerformed 方法。
            // 当按钮被点击时，会创建一个新的 AFrame5 对象，窗口标题为 "学生信息管理系统-修改"。
            b6.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    AFrame6 f4 = new AFrame6("学生信息管理系统-删除");

                }
            });
            //为 b6 按钮添加一个动作监听器，实现其 actionPerformed 方法。
            // 当按钮被点击时，会创建一个新的 AFrame6 对象，窗口标题为 "学生信息管理系统-删除"。

            this.setLayout(null);
            //使用绝对布局
            this.setBounds(300, 300, 1200, 1000);
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }
    }

    //下面这个类是录入界面的
    class AFrame3 extends JFrame {
        JTextField t3;
        JTextField t4;
        JTextField t5;
        JTextField t6;
        JTextField t7;
        JLabel nameLabel2;
        JLabel studentnumber;
        JLabel major;
        JLabel age;
        JLabel sex;
        JButton b7;
        JButton b8;
        JLabel l1;

        public AFrame3(String title) {
            super(title);
            //构造函数AFrame3接收一个字符串参数title，表示窗口的标题。
            this.setLayout(null);
            //绝对布局

            l1 = new JLabel("录入系统");
            l1.setForeground(Color.gray);
            l1.setFont(new Font("宋体", Font.BOLD, 20));
            l1.setHorizontalAlignment(JTextField.CENTER);
            nameLabel2 = new JLabel("姓名：");
            nameLabel2.setFont(new Font("宋体", Font.BOLD, 25));
            nameLabel2.setHorizontalAlignment(JTextField.CENTER);
            major = new JLabel("专业：");
            major.setFont(new Font("宋体", Font.BOLD, 25));
            major.setHorizontalAlignment(JTextField.CENTER);
            age = new JLabel("年龄：");
            age.setFont(new Font("宋体", Font.BOLD, 25));
            age.setHorizontalAlignment(JTextField.CENTER);
            sex = new JLabel("性别：");
            sex.setFont(new Font("宋体", Font.BOLD, 25));
            sex.setHorizontalAlignment(JTextField.CENTER);
            studentnumber = new JLabel("学号：");
            studentnumber.setFont(new Font("宋体", Font.BOLD, 25));
            studentnumber.setHorizontalAlignment(JTextField.CENTER);

            //上述代码用来设置文本框对应左边文字大小

            t3 = new JTextField(25);
            t3.setFont(new Font("宋体", Font.BOLD, 25));
            t4 = new JTextField(25);
            t4.setFont(new Font("宋体", Font.BOLD, 25));
            t5 = new JTextField(25);
            t5.setFont(new Font("宋体", Font.BOLD, 25));
            t6 = new JTextField(25);
            t6.setFont(new Font("宋体", Font.BOLD, 25));
            t7 = new JTextField(25);
            t7.setFont(new Font("宋体", Font.BOLD, 25));

            //上述代码用来设置文本框内文字大小

            b7 = new JButton("录入");
            b8 = new JButton("取消");

            b7.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    DatabaseConnection insert = new DatabaseConnection();
                    insert.databaseinsert(t3.getText(), t4.getText(), t5.getText(), t6.getText(), t7.getText());
                }
            });

//            b8.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, "单击确定退出");
//                    //System.exit(0);
//                    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//                }
//            });
            b8.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "单击确定退出");
                    Window window = SwingUtilities.getWindowAncestor(b8);
                    window.dispose();
                }
            });

            //为按钮b8添加动作监听器，当按钮被点击时触发actionPerformed方法。

            this.add(t3);
            this.add(t4);
            this.add(t5);
            this.add(t6);
            this.add(t7);
            this.add(nameLabel2);
            this.add(major);
            this.add(age);
            this.add(sex);
            this.add(studentnumber);
            this.add(l1);
            this.add(b8);
            this.add(b7);

            //添加录入模块的各个部分


            t3.setBounds(180, 40, 180, 50);
            t4.setBounds(180, 100, 180, 50);
            t5.setBounds(180, 160, 180, 50);
            t6.setBounds(180, 220, 180, 50);
            t7.setBounds(180, 280, 180, 50);
            nameLabel2.setBounds(0, 40, 180, 50);
            age.setBounds(0, 100, 180, 50);
            sex.setBounds(0, 160, 180, 50);
            studentnumber.setBounds(0, 220, 180, 50);
            major.setBounds(0, 280, 180, 50);
            l1.setBounds(0, 0, 360, 40);
            b7.setBounds(50, 360, 100, 50);
            b8.setBounds(220, 360, 100, 50);

            //为录入模块设置大小

            this.setBounds(900, 300, 400, 500);
            //设置单击录入后呈现的模块的大小
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }
    }

    //查询界面
    class A4 extends JFrame {
        JLabel t3;
        JLabel t4;
        JLabel t5;
        JLabel t6;
        JLabel t7;
        JLabel nameLabel2;
        JLabel studentnumber;
        JLabel major;
        JLabel age;
        JLabel sex;
        JButton b7;
        JButton b8;
        JLabel l1;

        public A4(String title) {
            super(title);
            //构造函数AFrame3接收一个字符串参数title，表示窗口的标题。
            this.setLayout(null);
            //绝对布局

            l1 = new JLabel("查询系统");
            l1.setForeground(Color.gray);
            l1.setFont(new Font("宋体", Font.BOLD, 20));
            l1.setHorizontalAlignment(JTextField.CENTER);
            nameLabel2 = new JLabel("姓名：");
            nameLabel2.setFont(new Font("宋体", Font.BOLD, 25));
            nameLabel2.setHorizontalAlignment(JTextField.CENTER);
            major = new JLabel("专业：");
            major.setFont(new Font("宋体", Font.BOLD, 25));
            major.setHorizontalAlignment(JTextField.CENTER);
            age = new JLabel("年龄：");
            age.setFont(new Font("宋体", Font.BOLD, 25));
            age.setHorizontalAlignment(JTextField.CENTER);
            sex = new JLabel("性别：");
            sex.setFont(new Font("宋体", Font.BOLD, 25));
            sex.setHorizontalAlignment(JTextField.CENTER);
            studentnumber = new JLabel("学号：");
            studentnumber.setFont(new Font("宋体", Font.BOLD, 25));
            studentnumber.setHorizontalAlignment(JTextField.CENTER);

            //上述代码用来设置文本框对应左边文字大小


            //上述代码用来设置文本框内文字大小

            b8 = new JButton("退出");


//            b8.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, "单击确定退出");
//                    //System.exit(0);
//                    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//                }
//            });
            b8.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "单击确定退出");
                    Window window = SwingUtilities.getWindowAncestor(b8);
                    window.dispose();
                }
            });
            //为按钮b8添加动作监听器，当按钮被点击时触发actionPerformed方法。


            this.add(nameLabel2);
            this.add(major);
            this.add(age);
            this.add(sex);
            this.add(studentnumber);
            this.add(l1);
            this.add(b8);

            //添加录入模块的各个部分


            nameLabel2.setBounds(0, 40, 180, 50);
            age.setBounds(0, 100, 180, 50);
            sex.setBounds(0, 160, 180, 50);
            studentnumber.setBounds(0, 220, 180, 50);
            major.setBounds(0, 280, 180, 50);
            l1.setBounds(0, 0, 360, 40);
            b8.setBounds(220, 360, 100, 50);

            //为录入模块设置大小

            this.setBounds(900, 300, 400, 500);
            //设置单击录入后呈现的模块的大小
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }

        public void qc(String n1, String n2, String n3, String n4, String n5) {
            //System.out.println("应该调用了");
            t3 = new JLabel(n1);
            t3.setFont(new Font("宋体", Font.BOLD, 25));
            t3.setHorizontalAlignment(JTextField.CENTER);
            t4 = new JLabel(n2);
            t4.setFont(new Font("宋体", Font.BOLD, 25));
            t4.setHorizontalAlignment(JTextField.CENTER);
            t5 = new JLabel(n3);
            t5.setFont(new Font("宋体", Font.BOLD, 25));
            t5.setHorizontalAlignment(JTextField.CENTER);
            t6 = new JLabel(n4);
            t6.setFont(new Font("宋体", Font.BOLD, 25));
            t6.setHorizontalAlignment(JTextField.CENTER);
            t7 = new JLabel(n5);
            t7.setFont(new Font("宋体", Font.BOLD, 25));
            t7.setHorizontalAlignment(JTextField.CENTER);
            this.add(t3);
            this.add(t4);
            this.add(t5);
            this.add(t6);
            this.add(t7);
            t3.setBounds(180, 40, 180, 50);
            t4.setBounds(180, 100, 180, 50);
            t5.setBounds(180, 160, 180, 50);
            t6.setBounds(180, 220, 180, 50);
            t7.setBounds(180, 280, 180, 50);
        }

    }

    class A5 extends JFrame {
        JTextField t3;
        JTextField t4;
        JTextField t5;
        JTextField t6;
        JTextField t7;
        JLabel nameLabel2;
        JLabel studentnumber;
        JLabel major;
        JLabel age;
        JLabel sex;
        JButton b7;
        JButton b8;
        JLabel l1;

        public A5(String title) {
            super(title);
            //构造函数AFrame3接收一个字符串参数title，表示窗口的标题。
            this.setLayout(null);
            //绝对布局

            l1 = new JLabel("修改系统");
            l1.setForeground(Color.gray);
            l1.setFont(new Font("宋体", Font.BOLD, 20));
            l1.setHorizontalAlignment(JTextField.CENTER);
            nameLabel2 = new JLabel("姓名：");
            nameLabel2.setFont(new Font("宋体", Font.BOLD, 25));
            nameLabel2.setHorizontalAlignment(JTextField.CENTER);
            major = new JLabel("专业：");
            major.setFont(new Font("宋体", Font.BOLD, 25));
            major.setHorizontalAlignment(JTextField.CENTER);
            age = new JLabel("年龄：");
            age.setFont(new Font("宋体", Font.BOLD, 25));
            age.setHorizontalAlignment(JTextField.CENTER);
            sex = new JLabel("性别：");
            sex.setFont(new Font("宋体", Font.BOLD, 25));
            sex.setHorizontalAlignment(JTextField.CENTER);
            studentnumber = new JLabel("学号：");
            studentnumber.setFont(new Font("宋体", Font.BOLD, 25));
            studentnumber.setHorizontalAlignment(JTextField.CENTER);

            //上述代码用来设置文本框对应左边文字大小

            t3 = new JTextField(25);
            t3.setFont(new Font("宋体", Font.BOLD, 25));
            t4 = new JTextField(25);
            t4.setFont(new Font("宋体", Font.BOLD, 25));
            t5 = new JTextField(25);
            t5.setFont(new Font("宋体", Font.BOLD, 25));
            t6 = new JTextField(25);
            t6.setFont(new Font("宋体", Font.BOLD, 25));
            t7 = new JTextField(25);
            t7.setFont(new Font("宋体", Font.BOLD, 25));

            //上述代码用来设置文本框内文字大小

            b7 = new JButton("修改");
            b8 = new JButton("取消");

            b7.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    DatabaseConnection update = new DatabaseConnection();
                    update.databaseupdate(t3.getText(), t4.getText(), t5.getText(), t6.getText(), t7.getText());
                }
            });

//            b8.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, "单击确定退出");
//                    //System.exit(0);
//                    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//                }
//            });
            b8.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "单击确定退出");
                    Window window = SwingUtilities.getWindowAncestor(b8);
                    window.dispose();
                }
            });
            //为按钮b8添加动作监听器，当按钮被点击时触发actionPerformed方法。

            this.add(t3);
            this.add(t4);
            this.add(t5);
            this.add(t6);
            this.add(t7);
            this.add(nameLabel2);
            this.add(major);
            this.add(age);
            this.add(sex);
            this.add(studentnumber);
            this.add(l1);
            this.add(b8);
            this.add(b7);

            //添加录入模块的各个部分


            t3.setBounds(180, 40, 180, 50);
            t4.setBounds(180, 100, 180, 50);
            t5.setBounds(180, 160, 180, 50);
            t6.setBounds(180, 220, 180, 50);
            t7.setBounds(180, 280, 180, 50);
            nameLabel2.setBounds(0, 40, 180, 50);
            age.setBounds(0, 100, 180, 50);
            sex.setBounds(0, 160, 180, 50);
            studentnumber.setBounds(0, 220, 180, 50);
            major.setBounds(0, 280, 180, 50);
            l1.setBounds(0, 0, 360, 40);
            b7.setBounds(50, 360, 100, 50);
            b8.setBounds(220, 360, 100, 50);

            //为录入模块设置大小

            this.setBounds(900, 300, 400, 500);
            //设置单击录入后呈现的模块的大小
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }
    }

    class AFrame4 extends JFrame {
        JButton b9;
        JButton b10;
        JTextField t8;
        JLabel l2;
        JLabel l3;

        public AFrame4(String title) {
            super(title);
            b9 = new JButton("查询");
            b10 = new JButton("取消");
            t8 = new JTextField(25);
            //输入学号的文本框
            t8.setFont(new Font("宋体", Font.BOLD, 25));
            l2 = new JLabel("输入学号：");
            l2.setFont(new Font("宋体", Font.BOLD, 25));
            //输入学号的标签的大小
            l2.setHorizontalAlignment(JTextField.CENTER);
            l3 = new JLabel("查询系统");
            l3.setForeground(Color.gray);
            l3.setFont(new Font("宋体", Font.BOLD, 20));
            l3.setHorizontalAlignment(JTextField.CENTER);

            this.add(b9);
            this.add(b10);
            this.add(t8);
            this.add(l2);
            this.add(l3);

            b9.setBounds(50, 300, 100, 50);
            b10.setBounds(200, 300, 100, 50);
            t8.setBounds(180, 160, 180, 50);
            l2.setBounds(0, 160, 180, 50);
            l3.setBounds(0, 0, 360, 40);

            //设置查询界面各个内容的位置和大小

            b9.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {


                    DatabaseConnection select = new DatabaseConnection();
                    List<String> result = select.databaseselect(t8.getText());
                    String n1 = null;
                    String n2 = null;
                    String n3 = null;
                    String n4 = null;
                    String n5 = null;
                    n1 = result.get(0);
                    n2 = result.get(1);
                    n3 = result.get(2);
                    n4 = result.get(3);
                    n5 = result.get(4);

                    A4 a4 = new A4("查询系统");
                    a4.qc(n1, n2, n3, n4, n5);
                }
            });

//            b10.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, "单击确定退出");
//                    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//                }
//            });
            b10.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "单击确定退出");
                    Window window = SwingUtilities.getWindowAncestor(b10);
                    window.dispose();
                }
            });

            this.setLayout(null);
            this.setBounds(900, 300, 400, 500);
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }
    }

    class AFrame5 extends JFrame {
        JButton b9;
        JButton b10;
        JTextField t8;
        JLabel l2;
        JLabel l3;

        public AFrame5(String title) {
            super(title);
            b9 = new JButton("修改");
            b10 = new JButton("取消");
            t8 = new JTextField(25);
            //输入学号的文本框
            t8.setFont(new Font("宋体", Font.BOLD, 25));
            l2 = new JLabel("输入学号：");
            l2.setFont(new Font("宋体", Font.BOLD, 25));
            //输入学号的标签的大小
            l2.setHorizontalAlignment(JTextField.CENTER);
            l3 = new JLabel("修改系统");
            l3.setForeground(Color.gray);
            l3.setFont(new Font("宋体", Font.BOLD, 20));
            l3.setHorizontalAlignment(JTextField.CENTER);

            this.add(b9);
            this.add(b10);
            this.add(t8);
            this.add(l2);
            this.add(l3);

            b9.setBounds(50, 300, 100, 50);
            b10.setBounds(200, 300, 100, 50);
            t8.setBounds(180, 160, 180, 50);
            l2.setBounds(0, 160, 180, 50);
            l3.setBounds(0, 0, 360, 40);

            //设置查询界面各个内容的位置和大小

            b9.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    A5 a5 = new A5("修改系统");


                }
            });

//            b10.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, "单击确定退出");
//                    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//                }
//            });
            b10.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "单击确定退出");
                    Window window = SwingUtilities.getWindowAncestor(b10);
                    window.dispose();
                }
            });

            this.setLayout(null);
            this.setBounds(900, 300, 400, 500);
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }
    }

    class AFrame6 extends JFrame {
        JButton b9;
        JButton b10;
        JTextField t8;
        JLabel l2;
        JLabel l3;

        public AFrame6(String title) {
            super(title);
            b9 = new JButton("删除");
            b10 = new JButton("取消");
            t8 = new JTextField(25);
            //输入学号的文本框
            t8.setFont(new Font("宋体", Font.BOLD, 25));
            l2 = new JLabel("输入学号：");
            l2.setFont(new Font("宋体", Font.BOLD, 25));
            //输入学号的标签的大小
            l2.setHorizontalAlignment(JTextField.CENTER);
            l3 = new JLabel("删除系统");
            l3.setForeground(Color.gray);
            l3.setFont(new Font("宋体", Font.BOLD, 20));
            l3.setHorizontalAlignment(JTextField.CENTER);

            this.add(b9);
            this.add(b10);
            this.add(t8);
            this.add(l2);
            this.add(l3);

            b9.setBounds(50, 300, 100, 50);
            b10.setBounds(200, 300, 100, 50);
            t8.setBounds(180, 160, 180, 50);
            l2.setBounds(0, 160, 180, 50);
            l3.setBounds(0, 0, 360, 40);

            b9.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    DatabaseConnection delete=new DatabaseConnection();
                    delete.databasedelete(t8.getText());
                }
            });


//            b10.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, "单击确定退出");
//                    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//                }
//            });
            b10.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "单击确定退出");
                    Window window = SwingUtilities.getWindowAncestor(b10);
                    window.dispose();
                }
            });

            this.setLayout(null);
            this.setBounds(900, 300, 400, 500);
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.setVisible(true);
        }
    }

    class DatabaseConnection {
        private static final String DB_URL = "jdbc:mysql://localhost:3306";
        private static final String DB_USER = "root";
        private static final String DB_PASSWORD = "wangzhi123";

        public void databaseinsert(String name, String Sage, String gender, String Snumber, String pro) {
            Connection connection = null;
            Statement statement = null;

            try {
                // 加载数据库驱动
                Class.forName("com.mysql.jdbc.Driver");

                // 建立数据库连接
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                statement = connection.createStatement();

                if (connection != null) {
                    System.out.println("数据库连接成功");

                    // 执行 SQL 语句
                    String sql1 = "USE test";
                    statement.execute(sql1);
                    // 获取文本框的值
                    int age = Integer.parseInt(Sage);
                    int number = Integer.parseInt(Snumber);

                    String sql = "insert into student_information(姓名, 年龄, 性别, 学号, 专业) VALUE ('" + name + "', " + age + ", '" + gender + "', " + number + ", '" + pro + "')";


                    int rowsAffected = statement.executeUpdate(sql);
                    System.out.println("SQL 执行成功");
                }
            } catch (ClassNotFoundException e) {
                System.out.println("驱动加载失败：" + e.getMessage());
            } catch (SQLException e) {
                System.out.println("数据库连接失败：" + e.getMessage());

            } finally {
                // 关闭连接和 statement
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        System.out.println("Statement 关闭失败：" + e.getMessage());
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                        System.out.println("数据库连接已关闭");
                    } catch (SQLException e) {
                        System.out.println("数据库连接关闭失败：" + e.getMessage());
                    }
                }
            }
        }

        public List<String> databaseselect(String Snumber) {
            {
                Connection connection = null;
                Statement statement = null;
                List<String> resultList = new ArrayList<>();

                try {
                    // 加载数据库驱动
                    Class.forName("com.mysql.jdbc.Driver");

                    // 建立数据库连接
                    connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    statement = connection.createStatement();

                    if (connection != null) {
                        System.out.println("数据库连接成功");

                        // 执行 SQL 语句
                        String sql1 = "USE test";
                        statement.execute(sql1);

                        statement = connection.createStatement();
                        int number = Integer.parseInt(Snumber);
                        ResultSet resultSet = statement.executeQuery("SELECT * FROM student_information where 学号=" + number);
                        ResultSetMetaData metaData = resultSet.getMetaData();
                        int columnCount = metaData.getColumnCount();
                        while (resultSet.next()) {
                            for (int i = 1; i <= columnCount; i++) {
                                String columnValue = resultSet.getString(i);
                                resultList.add(columnValue);
                            }
                        }


                        System.out.println("SQL 执行成功");
                    }
                } catch (ClassNotFoundException e) {
                    System.out.println("驱动加载失败：" + e.getMessage());
                } catch (SQLException e) {
                    System.out.println("数据库连接失败：" + e.getMessage());

                } finally {
                    // 关闭连接和 statement
                    if (statement != null) {
                        try {
                            statement.close();
                        } catch (SQLException e) {
                            System.out.println("Statement 关闭失败：" + e.getMessage());
                        }
                    }
                    if (connection != null) {
                        try {
                            connection.close();
                            System.out.println("数据库连接已关闭");
                        } catch (SQLException e) {
                            System.out.println("数据库连接关闭失败：" + e.getMessage());
                        }
                    }
                }
                return resultList;
            }

        }

        public void databaseupdate(String name, String Sage, String gender, String Snumber, String pro) {
            {
                try {

                    int age = Integer.parseInt(Sage);
                    int number = Integer.parseInt(Snumber);
                    // 建立数据库连接
                    Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    String databaseName = "test";
                    connection.setCatalog(databaseName);
                    // 创建PreparedStatement对象
                    String sql = "UPDATE student_information SET 姓名 = ?, 年龄 = ?, 性别 = ?, 学号 = ?, 专业 = ? WHERE 学号 = ?";
                    PreparedStatement statement = connection.prepareStatement(sql);

                    // 设置参数值
                    statement.setString(1, name);
                    statement.setInt(2, age);
                    statement.setString(3, gender);
                    statement.setInt(4, number);
                    statement.setString(5, pro);
                    statement.setInt(6, number);
                    // 执行修改
                    int rowsAffected = statement.executeUpdate();

                    // 关闭资源
                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        public void databasedelete(String Snumber) {
            {
                Connection connection = null;
                Statement statement = null;

                try {
                    // 加载数据库驱动
                    Class.forName("com.mysql.jdbc.Driver");

                    // 建立数据库连接
                    connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    statement = connection.createStatement();

                    if (connection != null) {
                        System.out.println("数据库连接成功");

                        // 执行 SQL 语句
                        String sql1 = "USE test";
                        statement.execute(sql1);

                        int number = Integer.parseInt(Snumber);

                        String sql = "DELETE FROM student_information WHERE 学号 = ?";
                        PreparedStatement statement1 = connection.prepareStatement(sql);

                        // 设置参数值
                        statement1.setInt(1,number);

                        // 执行删除
                        int rowsAffected = statement1.executeUpdate();




                        System.out.println("SQL 执行成功");
                    }
                } catch (ClassNotFoundException e) {
                    System.out.println("驱动加载失败：" + e.getMessage());
                } catch (SQLException e) {
                    System.out.println("数据库连接失败：" + e.getMessage());

                } finally {
                    // 关闭连接和 statement
                    if (statement != null) {
                        try {
                            statement.close();
                        } catch (SQLException e) {
                            System.out.println("Statement 关闭失败：" + e.getMessage());
                        }
                    }
                    if (connection != null) {
                        try {
                            connection.close();
                            System.out.println("数据库连接已关闭");
                        } catch (SQLException e) {
                            System.out.println("数据库连接关闭失败：" + e.getMessage());
                        }
                    }
                }
            }
        }
    }
}